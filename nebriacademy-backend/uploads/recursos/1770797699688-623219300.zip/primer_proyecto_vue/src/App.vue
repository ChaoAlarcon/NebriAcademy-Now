//Vue se compone de 3 partes por componente: script, template y style.

<script setup>

import { ref } from "vue";
import HeaderComponent from './components/HeaderComponent.vue';

let number = ref(0);

const addOne = () => {
  number.value++;
}

const myId = "patata";
const myValue = ref("nombre");
let myCondition = true;
let myCondition2 = false;

</script>


<template>

  <HeaderComponent />
  <h1 class="title" v-bind:id="myId">¡¡Bienvenidos a Vue!!</h1>
  <h1 :class="{ highlight: myCondition, red: myCondition2 }"></h1>

  <h2>{{ number }}</h2>
  <button @click="addOne">Suma 1</button>
  <h2> ¡Hola {{ myValue }}!</h2>
  <input type="text" v-model="myValue" />

  <h2 v-if="myCondition">La condición 1 se cumple</h2>
  <h2 v-else-if="myCondition2">La condición 2 se cumple</h2>
  <h2 v-else>Ninguna condición se cumple</h2>


  <input type="text" :value="myValue" @input="myValue = $event.target.value" />

</template>

//El scoped es importante a la hora de envolver componentes, para que los estilos del padre no afecten al hijo.
<style scoped>
.title {
  background-color: rgb(106, 106, 184);
  color: white;
}
</style>
