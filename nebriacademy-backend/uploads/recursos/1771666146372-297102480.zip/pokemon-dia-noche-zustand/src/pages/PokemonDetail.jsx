import { useParams, useNavigate, useLocation } from "react-router-dom";
import { pokemonData } from "../data/pokemonData";
import { usePokemonStore } from "../stores/pokemonStore";
import { useRef } from "react";

function PokemonDetail() {

  const { name } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const playSound = usePokemonStore(state => state.playSound);

  const pokemon = pokemonData[name];

  const audioRef = useRef(null);

  if(!pokemon) {
    return(
      <div className="pokemon-detail-page night">
        <div className="pokemon-detail">
          <h2>Pokémon no encontrado</h2>
          <button className="back-button" onClick={() => navigate("/")}>
            Volver al inicio
          </button>
        </div>
      </div>
    )
  }

  const themeClass = pokemon.period === "day" ? "day" : "night";

  const typeColors = {
    Planta: "#7bcf7b",
    Fuego: "#ff9f43",
    Agua: "#4dabf7",
    Fantasma: "#845ec2",
    "Bicho / Veneno": "#a30098",
    "Normal / Volador": "#a29bfe"
  };

  const handleImageClick = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(pokemon.sound);
    }

    playSound(audioRef.current);
  }

  let message = "";

  if(location.state?.fromHome) {
    message = location.state.message;
  }

  return (
    <div className={`pokemon-detail-page ${themeClass}`} >
      <div className="pokemon-detail">
        <p>
          {message}
        </p>
        <img 
          src={pokemon.img} 
          alt={`Imagen de ${pokemon.name}`} 
          className="pokemon-image"
          onClick={handleImageClick}
        />
        <h2>{pokemon.name}</h2>
        <span
          className="type"
          style={{ backgroundColor: typeColors[pokemon.type]}}
        >
          {pokemon.type}
        </span>
        <p className="description">
          {pokemon.description}
        </p>
        <button className="back-button" onClick={() => navigate(-1)}>
            Volver
          </button>
      </div>
    </div>
  )
}

export default PokemonDetail