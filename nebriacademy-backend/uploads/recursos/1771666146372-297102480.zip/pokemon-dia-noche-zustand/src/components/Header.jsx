import ThemeToggle from "./ThemeToggle";

function Header() {
  return (
    <header className="header">
      <h1>Pokémon Oro / Plata</h1>
      <ThemeToggle />
    </header>
  )
}

export default Header