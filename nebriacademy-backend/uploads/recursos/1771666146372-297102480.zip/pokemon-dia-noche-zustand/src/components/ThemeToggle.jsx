import { usePokemonStore } from "../stores/pokemonStore";

function ThemeToggle() {

  const theme = usePokemonStore(state => state.theme);
  const toggleTheme = usePokemonStore(state => state.toggleTheme);

  return (
    <button className="theme-toggle" onClick={toggleTheme}>
      {theme === "day" ? "☀️ Día" : "🌙 Noche"}
    </button>
  )
}

export default ThemeToggle;