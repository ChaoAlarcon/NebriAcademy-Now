import { useNavigate } from "react-router-dom";

function PokemonCard({ name, img }) {

  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/pokemon/${name.toLowerCase()}`, {
      state: {
        fromHome: true,
        message: "Has seleccionado este Pokémon desde Home"
      }
    });
  };
  
  return (
    <div 
      className="pokemon-card" 
      onClick={handleClick}
      tabIndex={0}
      onKeyDown={(event) => event.key === "Enter" && handleClick()}
    >
      <img src={img} alt={name}/>
      <h3>{name}</h3>
    </div>
  )
}

export default PokemonCard;