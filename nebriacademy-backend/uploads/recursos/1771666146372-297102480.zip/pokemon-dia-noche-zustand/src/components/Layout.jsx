import { usePokemonStore } from "../stores/pokemonStore";
import Header from "../components/Header";
import PokemonGrid from "../components/PokemonGrid";

function Layout() {

  const theme = usePokemonStore(state => state.theme);

  return (
    <div className={`app ${theme}`}>
      <Header />
      <PokemonGrid />
    </div>
  )
}

export default Layout;