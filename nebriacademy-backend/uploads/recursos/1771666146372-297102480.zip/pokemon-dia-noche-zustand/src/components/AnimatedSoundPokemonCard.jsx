import PokemonCard from "./PokemonCard";
import { withAnimation } from "../hoc/withAnimation";
import { withSound } from "../hoc/withSound";

const SoundPokemonCard = withSound(PokemonCard);

const AnimatedSoundPokemonCard = withAnimation(SoundPokemonCard);

export default AnimatedSoundPokemonCard;

