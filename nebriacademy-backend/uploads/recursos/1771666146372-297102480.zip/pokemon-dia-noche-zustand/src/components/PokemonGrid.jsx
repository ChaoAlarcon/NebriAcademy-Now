import { usePokemonStore } from "../stores/pokemonStore";
import AnimatedSoundPokemonCard from "./AnimatedSoundPokemonCard";
import { pokemonData } from "../data/pokemonData";

function PokemonGrid() {
  const theme = usePokemonStore(state => state.theme);

  const pokemonArray = Object.entries(pokemonData).map(
    ([id, pokemon]) => ({
      id,
      ...pokemon
    })
  )

  const filteredPokemon = pokemonArray.filter(
    pokemon => pokemon.period === theme
  )

  return (
    <main className="pokemon-grid">
      {filteredPokemon.map(pokemon => (
        <AnimatedSoundPokemonCard key={pokemon.id} {...pokemon}/>
      ))}
    </main>
  )
}

export default PokemonGrid;