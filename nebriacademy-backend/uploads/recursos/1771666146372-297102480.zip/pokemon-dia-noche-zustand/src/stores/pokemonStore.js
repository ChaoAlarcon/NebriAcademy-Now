import { create } from "zustand";

export const usePokemonStore = create(set => ({
  theme: "day",
  currentSound: null,
  toggleTheme: () => 
    set(state => ({
      theme: state.theme === "day" ? "night" : "day"
    })),
  playSound: (sound) => {
    if (sound) {
      sound.currentTime = 0;
      sound.play();
    }
    set({ currentSound: sound});
  }
}));