import { useState } from "react";

export function withAnimation(Component) {
  return function AnimatedComponent(props) {
    const [isClicked, setIsClicked] = useState(false);


    const handleClick = () => {
      setIsClicked(true);
      if (props.onClick){
        props.onClick();
      }
      setTimeout(() => {
        setIsClicked(false)
      }, 200);
    }

    return (
      <div className={`animated-wrapper ${isClicked ? 'clicked' : ''}`}>
        <Component { ...props } onClick={handleClick} />
      </div>
    )
  }
}