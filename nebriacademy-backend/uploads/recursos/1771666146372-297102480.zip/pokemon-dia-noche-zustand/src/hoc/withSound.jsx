import { useRef } from "react";

export function withSound(Component) {

  return function ComponentWithSound( { sound, ...props } ) {
    const audioRef = useRef(new Audio(sound));

    const playSound = () => {
      audioRef.current.currentTime = 0;
      audioRef.current.play();

      if(props.onClick) {
        props.onClick();
      }
    }

    return <Component {...props} onClick={playSound} />;
  }
}