import chikorita from "../assets/pokemon/day/chikorita.png";
import chikoritaSound from "../assets/pokemon/day/chikorita.mp3"
import cyndaquil from "../assets/pokemon/day/cyndaquil.png";
import cyndaquilSound from "../assets/pokemon/day/cyndaquil.mp3"
import totodile from "../assets/pokemon/day/totodile.png";
import totodileSound from "../assets/pokemon/day/totodile.mp3"
import gastly from "../assets/pokemon/night/gastly.png";
import gastlySound from "../assets/pokemon/night/gastly.mp3"
import hoothoot from "../assets/pokemon/night/hoothoot.png";
import hoothootSound from "../assets/pokemon/night/hoothoot.mp3"
import spinarak from "../assets/pokemon/night/spinarak.png";
import spinarakSound from "../assets/pokemon/night/spinarak.mp3"

export const pokemonData = {
  chikorita: {
    name: "Chikorita",
    type: "Planta",
    period: "day",
    description:
      "Chikorita usa la hoja de su cabeza para detectar la temperatura y la humedad",
    img: chikorita,
    sound: chikoritaSound
  },
  cyndaquil: {
    name: "Cyndaquil",
    type: "Fuego",
    period: "day",
    description:
      "Las llamas de su espalda se afilan cuando se defiende de un ataque enemigo",
    img: cyndaquil,
    sound: cyndaquilSound
  },
  totodile: {
    name: "Totodile",
    type: "Agua",
    period: "day",
    description:
      "La presa de sus enormes fauces es comparable a la de un cepo para osos",
    img: totodile,
    sound: totodileSound
  },
  gastly: {
    name: "Gastly",
    type: "Fantasma",
    period: "night",
    description:
      "Ronda los cementerios por la noche en busca de los incautos",
    img: gastly,
    sound: gastlySound
  },
  hoothoot: {
    name: "Hoothoot",
    type: "Normal / Volador",
    period: "night",
    description:
      "Hoothoot puede detectar el paso del tiempo con una precisión asombrosa",
    img: hoothoot,
    sound: hoothootSound
  },
  spinarak: {
    name: "Spinarak",
    type: "Bicho / Veneno",
    period: "night",
    description:
      "Teje resistentes redes donde espera que caigan posibles presas",
    img: spinarak,
    sound: spinarakSound
  }
};
